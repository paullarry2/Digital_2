/* 
 * File:   Adc_int.h
 * Author: Larry Paúl Fuentes
 * Carné 18117
 * Digital 2
 * Lab2
 * Created on 7 de febrero de 2021, 01:19 PM
 */

#ifndef __ADC_INT_H_
#define	__ADC_INT_H_

#include <xc.h>
#include <stdint.h>
//******************************************************************************
//Llamo Funciones
//******************************************************************************
void confADC(void);

#endif	/* XC_HEADER_TEMPLATE_H */

