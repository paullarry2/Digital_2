/* 
 * File:   Adc_int.h
 * Author: Universidad
 *
 * Created on 7 de febrero de 2021, 01:19 PM
 */

#ifndef ADC_INT_H
#define	ADC_INT_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ADC_INT_H */

